#!/bin/bash
# Run this command before running the script:
# chmod +x run.sh

# Install project dependencies
npm install

# Start the development server
npm run dev
