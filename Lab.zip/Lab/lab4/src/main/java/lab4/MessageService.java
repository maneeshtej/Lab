package lab4;

public interface MessageService {
    void sendMessage(String message, String recipient);
}
